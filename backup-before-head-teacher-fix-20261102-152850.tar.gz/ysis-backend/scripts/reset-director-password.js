require('dotenv').config({
  path: process.env.NODE_ENV === 'production'
    ? '.env.production'
    : '.env.development',
});

const readline = require('readline');
const { pool } = require('../src/db');
const { hashPassword } = require('../src/utils/hash');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function ask(question) {
  return new Promise(resolve => {
    rl.question(question, answer => resolve(answer.trim()));
  });
}

async function main() {
  try {
    const email = await ask('Existing Director email: ');
    const password = await ask('New temporary password: ');
    const confirm = await ask('Confirm temporary password: ');

    if (!email || !password) {
      throw new Error('Email and password are required.');
    }

    if (password !== confirm) {
      throw new Error('Passwords do not match.');
    }

    if (password.length < 12) {
      throw new Error('Use a password of at least 12 characters.');
    }

    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL is missing. Check your environment file.');
    }

    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      const result = await client.query(
        `SELECT id, full_name, email, role, status
         FROM users
         WHERE LOWER(email) = LOWER($1)
         FOR UPDATE`,
        [email]
      );

      if (result.rows.length !== 1) {
        throw new Error(
          result.rows.length === 0
            ? 'No existing account found with that email.'
            : 'Multiple accounts found. Reset cancelled.'
        );
      }

      const director = result.rows[0];

      if (director.role !== 'director') {
        throw new Error('Account is not a Director. Reset cancelled.');
      }

      if (director.status !== 'active') {
        throw new Error(
          `Director account status is ${director.status}. No changes made.`
        );
      }

      const passwordHash = await hashPassword(password);

      await client.query(
        `UPDATE users
         SET password_hash = $1,
             must_change_password = TRUE,
             failed_login_count = 0,
             locked_until = NULL,
             session_version = session_version + 1,
             updated_at = NOW()
         WHERE id = $2`,
        [passwordHash, director.id]
      );

      await client.query('COMMIT');

      console.log('\nSUCCESS: Director password reset completed.');
      console.log('Name:', director.full_name);
      console.log('Email:', director.email);
      console.log('Role: director');
      console.log('Must change password: TRUE');
      console.log('Previous sessions invalidated.');

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

  } finally {
    rl.close();
    await pool.end();
  }
}

main().catch(error => {
  console.error('\nRESET FAILED:', error.message);
  process.exitCode = 1;
});
