const { planPromotion, planUndoPromotion, validateEdit } = require('../utils/studentChangeRules');
const { normalizeStudent } = require('../utils/studentRules');
const db = require('../db');
const { validate: isUuid } = require('uuid');
const {
  applyConditionalUpdate,
  getCurrentServerState,
} = require('./studentService');
const {
  getScopeForUser,
  isWithinScope,
} = require('./studentScopeService');
const { uploadStudentPhoto } = require('./photoService');
const { userHasPermission } = require('./permissionService');
const { isAtMaxClass } = require('../utils/classProgression');
const { academicSessionFor, normalizeSession } = require('../utils/academicSession');

const VALID_DIVISIONS = ['primary', 'secondary'];

async function processOperation({
  operation,
  userId,
  userRole,
  deviceId,
}) {
  const {
    operationId,
    opType,
    entityId,
    payload,
    sequenceNo,
    createdAtClient,
  } = operation;

  let syncOpRowId;

  try {
    const existing = await db.query(
      'SELECT id, status FROM sync_operations WHERE operation_id = $1',
      [operationId]
    );

    if (existing.rows.length > 0) {
      return {
        operationId,
        status: existing.rows[0].status,
        alreadyProcessed: true,
      };
    }

    const insertResult = await db.query(
      `INSERT INTO sync_operations
         (operation_id, op_type, entity_id, payload, user_id, device_id,
          sequence_no, created_at_client, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending')
       RETURNING id`,
      [
        operationId,
        opType,
        entityId,
        JSON.stringify(payload),
        userId,
        deviceId,
        sequenceNo,
        createdAtClient,
      ]
    );

    syncOpRowId = insertResult.rows[0].id;
  } catch (insertErr) {
    console.error('sync_operations insert failed for', operationId, insertErr.message);
    return {
      operationId,
      status: 'failed',
      error: 'INVALID_OPERATION',
      message: 'This operation could not be recorded and was not applied. Please retry it.',
    };
  }

  try {
    if (
      (opType === 'promote_student' || opType === 'undo_promote_student' || opType === 'create_student') &&
      userRole !== 'principal' &&
      userRole !== 'director'
    ) {
      await markOpStatus(syncOpRowId, 'failed', 'Only the principal or director can do this.');
      return { operationId, status: 'failed', error: 'FORBIDDEN' };
    }

    if (opType === 'edit_student' || opType === 'promote_student' || opType === 'undo_promote_student') {
      if (
        (opType === 'promote_student' || opType === 'undo_promote_student') &&
        userRole !== 'principal' &&
        userRole !== 'director'
      ) {
        const allowed = await userHasPermission({
          userId,
          role: userRole,
          permissionCode: 'PROMOTE_STUDENT',
          atTime: new Date(createdAtClient),
        });

        if (!allowed) {
          await markOpStatus(
            syncOpRowId,
            'failed',
            'You do not have permission to promote students right now.'
          );
          return {
            operationId,
            status: 'failed',
            error: 'FORBIDDEN',
          };
        }
      }

      const currentStudent = await getCurrentServerState(entityId);

      if (!currentStudent) {
        await markOpStatus(
          syncOpRowId,
          'failed',
          'That student could not be found.'
        );
        return {
          operationId,
          status: 'failed',
          error: 'NOT_FOUND',
        };
      }

      const scope = await getScopeForUser({
        role: userRole,
        userId,
      });

      if (
        !isWithinScope(scope, {
          division: currentStudent.division,
          classLevel: currentStudent.class_level,
          arm: currentStudent.arm,
        })
      ) {
        await markOpStatus(
          syncOpRowId,
          'failed',
          'You do not have permission to modify this student.'
        );
        return {
          operationId,
          status: 'failed',
          error: 'FORBIDDEN',
        };
      }

      if (opType === 'edit_student') {
        const changes = payload.changes || {};

        if (userRole === 'head_teacher') {
          const HT_EDITABLE = ['full_name', 'gender', 'guardian_name', 'guardian_phone'];
          const blocked = Object.keys(changes).filter((k) => !HT_EDITABLE.includes(k));
          if (blocked.length > 0) {
            await markOpStatus(syncOpRowId, 'failed', 'Head teachers can only edit name, gender and guardian details.');
            return { operationId, status: 'failed', error: 'FORBIDDEN' };
          }
        }

        const touchesClassFields = [
          'division',
          'class_level',
          'arm',
        ].some((field) => field in changes);

        if (touchesClassFields) {
          const nextDivision =
            'division' in changes
              ? changes.division
              : currentStudent.division;

          const nextClassLevel =
            'class_level' in changes
              ? changes.class_level
              : currentStudent.class_level;

          const nextArm =
            'arm' in changes
              ? changes.arm
              : currentStudent.arm;

          if (
            !isWithinScope(scope, {
              division: nextDivision,
              classLevel: nextClassLevel,
              arm: nextArm,
            })
          ) {
            await markOpStatus(
              syncOpRowId,
              'failed',
              'You do not have permission to move this student into that class.'
            );
            return {
              operationId,
              status: 'failed',
              error: 'FORBIDDEN',
            };
          }
        }
      }

      if (opType === 'promote_student') {
        if (isAtMaxClass(currentStudent.class_level)) {
          await markOpStatus(
            syncOpRowId,
            'failed',
            'This student is already at SS3, the highest class. They should be graduated, not promoted.'
          );
          return {
            operationId,
            status: 'failed',
            error: 'ALREADY_AT_MAX_CLASS',
          };
        }
      }

      let finalChanges = payload.changes || {};

      if (opType === 'promote_student') {
        const plan = planPromotion(currentStudent, {
          newClassLevel: payload.newClassLevel,
          arm: payload.arm,
        });
        if (!plan.ok) {
          await markOpStatus(syncOpRowId, 'failed', plan.message);
          return { operationId, status: 'failed', error: plan.code };
        }
        finalChanges = plan.changes;
      }

      if (opType === 'undo_promote_student') {
        const plan = planUndoPromotion(currentStudent);
        if (!plan.ok) {
          await markOpStatus(syncOpRowId, 'failed', plan.message);
          return { operationId, status: 'failed', error: plan.code };
        }
        finalChanges = plan.changes;
      }

      if (opType === 'edit_student') {
        const check = validateEdit(currentStudent, finalChanges);
        if (!check.ok) {
          await markOpStatus(syncOpRowId, 'failed', check.message);
          return { operationId, status: 'failed', error: check.code };
        }
        finalChanges = check.changes;
      }

      const {
        updated,
        student,
        noOp,
      } = await applyConditionalUpdate({
        studentId: entityId,
        basedOnVersion: payload.based_on_version,
        changes: finalChanges,
      });

      if (noOp) {
        await markOpStatus(syncOpRowId, 'synced');
        return {
          operationId,
          status: 'synced',
        };
      }

      if (!updated) {
        const serverState = await db.query(
          'SELECT * FROM students WHERE id = $1',
          [entityId]
        );

        await db.query(
          `INSERT INTO conflicts
             (sync_operation_id, student_id, conflict_summary, server_state, incoming_change)
           VALUES ($1, $2, $3, $4, $5)`,
          [
            syncOpRowId,
            entityId,
            'This student\'s record changed before this update could be applied.',
            JSON.stringify(serverState.rows[0] || {}),
            JSON.stringify(payload),
          ]
        );

        await markOpStatus(syncOpRowId, 'conflicted');
        return {
          operationId,
          status: 'conflicted',
        };
      }

      await markOpStatus(syncOpRowId, 'synced');
      return {
        operationId,
        status: 'synced',
        student,
      };
    }

    if (opType === 'create_student') {
      let {
        id,
        admissionNo,
        fullName,
        division,
        classLevel,
        arm,
        dateOfBirth,
        gender,
        guardianName,
        guardianPhone,
        academicSession,
      } = payload || {};

      if (!id || !admissionNo || !fullName || !division || !classLevel) {
        await markOpStatus(
          syncOpRowId,
          'failed',
          'create_student payload is missing required fields.'
        );
        return {
          operationId,
          status: 'failed',
          error: 'VALIDATION_ERROR',
        };
      }

      if (!isUuid(id)) {
        await markOpStatus(
          syncOpRowId,
          'failed',
          'create_student payload has an invalid id (must be a UUID).'
        );
        return {
          operationId,
          status: 'failed',
          error: 'VALIDATION_ERROR',
        };
      }

      if (!VALID_DIVISIONS.includes(division)) {
        await markOpStatus(
          syncOpRowId,
          'failed',
          `create_student payload has an invalid division (must be one of: ${VALID_DIVISIONS.join(', ')}).`
        );
        return {
          operationId,
          status: 'failed',
          error: 'VALIDATION_ERROR',
        };
      }

      const norm = normalizeStudent({
        admissionNo,
        fullName,
        division,
        classLevel,
        arm,
        gender,
        guardianName,
        guardianPhone,
        dateOfBirth,
      });
      if (!norm.ok) {
        await markOpStatus(syncOpRowId, 'failed', norm.errors[0]);
        return {
          operationId,
          status: 'failed',
          error: 'VALIDATION_ERROR',
        };
      }
      ({
        admissionNo,
        fullName,
        division,
        classLevel,
        arm,
        gender,
        guardianName,
        guardianPhone,
        dateOfBirth,
      } = norm.value);

      // The session the student was admitted. Older app builds send none, so
      // those fall back to the registration date.
      let sessionValue = null;
      if (academicSession === undefined || academicSession === null || academicSession === '') {
        sessionValue = academicSessionFor(createdAtClient);
      } else {
        sessionValue = normalizeSession(academicSession);
        if (!sessionValue) {
          await markOpStatus(
            syncOpRowId,
            'failed',
            'academicSession: not a session the school can choose.'
          );
          return {
            operationId,
            status: 'failed',
            error: 'VALIDATION_ERROR',
          };
        }
      }

      const scope = await getScopeForUser({
        role: userRole,
        userId,
      });

      if (
        !isWithinScope(scope, {
          division,
          classLevel,
          arm: arm || null,
        })
      ) {
        await markOpStatus(
          syncOpRowId,
          'failed',
          'You do not have permission to register students in this class.'
        );
        return {
          operationId,
          status: 'failed',
          error: 'FORBIDDEN',
        };
      }

      try {
        await db.query(
          `INSERT INTO students
             (
               id,
               admission_no,
               full_name,
               division,
               class_level,
               arm,
               date_of_birth,
               gender,
               guardian_name,
               guardian_phone,
               registered_by,
               registered_device_id,
               academic_session,
               current_session,
               created_at
             )
           VALUES
             ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,
          [
            id,
            admissionNo,
            fullName,
            division,
            classLevel,
            arm || null,
            dateOfBirth || null,
            gender || null,
            guardianName || null,
            guardianPhone || null,
            userId,
            deviceId,
            sessionValue,
            sessionValue,
            createdAtClient,
          ]
        );

        await markOpStatus(syncOpRowId, 'synced');
        return {
          operationId,
          status: 'synced',
        };
      } catch (dbErr) {
        if (
          dbErr.code === '23505' &&
          (dbErr.constraint === 'students_admission_no_key' ||
            (dbErr.detail && String(dbErr.detail).includes('admission_no')))
        ) {
          const existing = await db.query(
            'SELECT id FROM students WHERE admission_no = $1',
            [admissionNo]
          );
          const existingId = existing.rows[0]?.id;

          if (existingId && existingId !== id) {
            await markOpStatus(
              syncOpRowId,
              'conflicted',
              'Admission number already in use by another student.'
            );
            return {
              operationId,
              status: 'conflicted',
              error: 'ADMISSION_NUMBER_COLLISION',
              message: `Admission number "${admissionNo}" is already used by another student. Change it and resave.`,
            };
          }

          await markOpStatus(syncOpRowId, 'synced');
          return {
            operationId,
            status: 'synced',
          };
        }

        if (dbErr.code === '23505') {
          const detail = dbErr.detail || dbErr.message || 'A unique database constraint was violated.';
          await markOpStatus(syncOpRowId, 'failed', detail);
          return {
            operationId,
            status: 'failed',
            error: 'CREATE_STUDENT_DUPLICATE',
            message: detail,
          };
        }

        await markOpStatus(syncOpRowId, 'failed', dbErr.message);
        return {
          operationId,
          status: 'failed',
          error: 'CREATE_STUDENT_FAILED',
          message: dbErr.message || 'This record could not be saved to the server.',
        };
      }
    }

    if (opType === 'upload_photo') {
      const currentStudent = await getCurrentServerState(entityId);

      if (!currentStudent) {
        await markOpStatus(
          syncOpRowId,
          'failed',
          'That student could not be found.'
        );
        return {
          operationId,
          status: 'failed',
          error: 'NOT_FOUND',
        };
      }

      const scope = await getScopeForUser({
        role: userRole,
        userId,
      });

      if (
        !isWithinScope(scope, {
          division: currentStudent.division,
          classLevel: currentStudent.class_level,
          arm: currentStudent.arm,
        })
      ) {
        await markOpStatus(
          syncOpRowId,
          'failed',
          "You do not have permission to update this student's photo."
        );
        return {
          operationId,
          status: 'failed',
          error: 'FORBIDDEN',
        };
      }

      try {
        await uploadStudentPhoto({
          studentId: entityId,
          uploaderId: userId,
          uploaderRole: userRole,
          deviceId,
          imageBase64: payload.imageBase64,
          correctionReason: payload.correctionReason,
        });

        await markOpStatus(syncOpRowId, 'synced');
        return {
          operationId,
          status: 'synced',
        };
      } catch (photoErr) {
        await markOpStatus(
          syncOpRowId,
          'failed',
          photoErr.message
        );
        return {
          operationId,
          status: 'failed',
          error: photoErr.code || 'PHOTO_UPLOAD_FAILED',
        };
      }
    }

    await markOpStatus(
      syncOpRowId,
      'failed',
      'Unknown operation type'
    );

    return {
      operationId,
      status: 'failed',
    };
  } catch (err) {
    await markOpStatus(
      syncOpRowId,
      'failed',
      err.message
    );
    return {
      operationId,
      status: 'failed',
      error: 'PROCESSING_ERROR',
    };
  }
}

async function markOpStatus(
  id,
  status,
  errorMessage = null
) {
  await db.query(
    `UPDATE sync_operations
     SET status = $2, processed_at = now(), error_message = $3,
         payload = CASE
           WHEN op_type = 'upload_photo' AND $4::text IN ('synced', 'failed')
           THEN payload - 'imageBase64'
           ELSE payload
         END
     WHERE id = $1`,
    [id, status, errorMessage, status]
  );
}

async function processBatch({
  operations,
  userId,
  userRole,
  deviceId,
  batchId,
}) {
  const sorted = [...operations].sort(
    (a, b) => a.sequenceNo - b.sequenceNo
  );

  const results = [];

  for (const op of sorted) {
    let result;
    try {
      result = await processOperation({
        operation: op,
        userId,
        userRole,
        deviceId,
      });
    } catch (err) {
      console.error('Unexpected error processing sync op', op.operationId, err);
      result = { operationId: op.operationId, status: 'failed', error: 'PROCESSING_ERROR' };
    }

    results.push(result);

    if (batchId) {
      await db.query(
        'UPDATE sync_operations SET batch_id = $2 WHERE operation_id = $1',
        [op.operationId, batchId]
      );
    }
  }

  return results;
}

module.exports = {
  processOperation,
  processBatch,
};
