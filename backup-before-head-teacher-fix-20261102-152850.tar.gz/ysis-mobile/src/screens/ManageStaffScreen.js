import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  Alert,
  RefreshControl,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { api } from '../api/client';
import { useTheme } from '../theme/ThemeContext';
import { fontFamily } from '../theme/typography';
import { radius, shadow } from '../theme/spacing';

export default function ManageStaffScreen({ navigation }) {
  const { user } = useAuth();
  const { colors } = useTheme();
  const isDirector = user?.role === 'director';
  const staffLabel = isDirector ? 'Staff accounts' : 'Head Teachers';
  const createLabel = isDirector ? 'Create Principal' : 'Create Head Teacher';

  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadStaff = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    try {
      const result = await api.get('/users');
      setStaff(result.users || []);
    } catch (err) {
      if (!err.isNetworkError) {
        Alert.alert('Could not load staff', err.message || 'Something went wrong.');
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadStaff();
    }, [loadStaff])
  );

  // Director can permanently delete principals and head teachers they created.
  const canDelete = (member) =>
    isDirector && (member.role === 'principal' || member.role === 'head_teacher');

  const toggleStatus = (member) => {
    const nextStatus = member.status === 'active' ? 'suspended' : 'active';
    const verb = nextStatus === 'suspended' ? 'Disable' : 'Enable';
    const name = member.fullName || 'This account';

    Alert.alert(
      `${verb} account?`,
      `${name} will ${
        nextStatus === 'suspended'
          ? 'no longer be able to sign in.'
          : 'be able to sign in again.'
      }`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: verb,
          style: nextStatus === 'suspended' ? 'destructive' : 'default',
          onPress: async () => {
            try {
              const result = await api.patch(`/users/${member.id}/status`, {
                status: nextStatus,
              });
              setStaff((prev) => prev.map((s) => (s.id === member.id ? result.user : s)));
            } catch (err) {
              Alert.alert('Could not update account', err.message || 'Something went wrong.');
            }
          },
        },
      ]
    );
  };

  const deleteMember = (member) => {
    const name = member.fullName || 'This account';
    const roleLabel =
      member.role === 'principal' ? 'principal' : 'head teacher';

    Alert.alert(
      `Delete ${roleLabel}?`,
      `${name} will be permanently removed from the database and will no longer be able to sign in. Audit history that mentioned this account is kept.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete permanently',
          style: 'destructive',
          onPress: async () => {
            try {
              await api.delete(`/users/${member.id}`);
              setStaff((prev) => prev.filter((s) => s.id !== member.id));
            } catch (err) {
              Alert.alert('Could not delete account', err.message || 'Something went wrong.');
            }
          },
        },
      ]
    );
  };

  const getInitials = (name = '') => {
    const parts = String(name).trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0) return '?';
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const roleLabel = (role) => {
    if (role === 'principal') return 'Principal';
    if (role === 'head_teacher') return 'Head Teacher';
    return role || 'Staff';
  };

  const renderItem = ({ item }) => {
    const name = item.fullName || 'Staff';
    const email = item.email || '';
    const suspended = (item.status || 'active') === 'suspended';

    return (
      <View
        style={[
          styles.card,
          { backgroundColor: colors.surfaceAlt || '#17263B', borderColor: colors.border },
        ]}
      >
        <View style={[styles.avatar, { backgroundColor: colors.inkSoft }]}>
          <Text style={styles.avatarText}>{getInitials(name)}</Text>
        </View>

        <View style={styles.cardBody}>
          <Text style={[styles.name, { color: colors.textPrimary }]} numberOfLines={1}>
            {name}
          </Text>
          <Text style={[styles.email, { color: colors.textSecondary }]} numberOfLines={1}>
            {email}
          </Text>
          <View style={styles.statusRow}>
            <View
              style={[
                styles.statusDot,
                { backgroundColor: suspended ? colors.error : colors.success },
              ]}
            />
            <Text
              style={[
                styles.statusText,
                { color: suspended ? colors.error : colors.success },
              ]}
            >
              {suspended ? 'Suspended' : 'Active'}
            </Text>
            {isDirector && item.role ? (
              <Text
                style={[
                  styles.statusText,
                  { color: colors.textSecondary, marginLeft: 10 },
                ]}
              >
                · {roleLabel(item.role)}
              </Text>
            ) : null}
          </View>
        </View>

        <View style={styles.actions}>
          <Pressable
            onPress={() => toggleStatus(item)}
            style={[
              styles.actionBtn,
              { backgroundColor: suspended ? colors.success : colors.errorBg },
            ]}
          >
            <Text
              style={[
                styles.actionText,
                { color: suspended ? colors.textInverse : colors.error },
              ]}
            >
              {suspended ? 'Enable' : 'Disable'}
            </Text>
          </Pressable>

          {canDelete(item) && (
            <Pressable
              onPress={() => deleteMember(item)}
              style={[styles.actionBtn, { backgroundColor: colors.error }]}
            >
              <Text style={[styles.actionText, { color: colors.textInverse }]}>Delete</Text>
            </Pressable>
          )}
        </View>
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.headerBlock}>
        <Text style={[styles.eyebrow, { color: colors.gold }]}>STAFF</Text>
        <Text style={[styles.title, { color: colors.textPrimary }]}>{staffLabel}</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Accounts you created and manage
        </Text>
      </View>

      {isDirector ? (
        <View style={styles.createGroup}>
          <Pressable
            style={[styles.createBtn, { backgroundColor: colors.inkSoft }]}
            onPress={() =>
              navigation.navigate('CreateAccount', { targetRole: 'principal' })
            }
          >
            <Ionicons name="person-add" size={18} color={colors.textInverse} />
            <Text style={[styles.createBtnText, { color: colors.textInverse }]}>
              Create Principal
            </Text>
          </Pressable>
          <Pressable
            style={[styles.createBtn, styles.createBtnSecondary, { borderColor: colors.border }]}
            onPress={() =>
              navigation.navigate('CreateAccount', {
                targetRole: 'head_teacher',
                division: 'primary',
              })
            }
          >
            <Ionicons name="school-outline" size={18} color={colors.textPrimary} />
            <Text style={[styles.createBtnText, { color: colors.textPrimary }]}>
              Create Primary school HT
            </Text>
          </Pressable>
          <Pressable
            style={[styles.createBtn, styles.createBtnSecondary, { borderColor: colors.border }]}
            onPress={() =>
              navigation.navigate('CreateAccount', {
                targetRole: 'head_teacher',
                division: 'secondary',
              })
            }
          >
            <Ionicons name="school-outline" size={18} color={colors.textPrimary} />
            <Text style={[styles.createBtnText, { color: colors.textPrimary }]}>
              Create Secondary school HT
            </Text>
          </Pressable>
        </View>
      ) : (
        <View style={styles.createGroup}>
          <Pressable
            style={[styles.createBtn, { backgroundColor: colors.inkSoft }]}
            onPress={() => navigation.navigate('CreateAccount')}
          >
            <Ionicons name="person-add" size={18} color={colors.textInverse} />
            <Text style={[styles.createBtnText, { color: colors.textInverse }]}>{createLabel}</Text>
          </Pressable>
        </View>
      )}

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.gold} />
        </View>
      ) : (
        <FlatList
          data={staff}
          keyExtractor={(item) => String(item.id)}
          renderItem={renderItem}
          contentContainerStyle={[styles.list, staff.length === 0 && styles.emptyList]}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => loadStaff(true)}
              tintColor={colors.gold}
            />
          }
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="people-outline" size={36} color={colors.textMuted} />
              <Text style={[styles.emptyTitle, { color: colors.textPrimary }]}>
                No {staffLabel.toLowerCase()} yet
              </Text>
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                Tap "{createLabel}" to add the first account.
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerBlock: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 8,
  },
  eyebrow: {
    fontFamily: fontFamily.bodyBold,
    fontSize: 11,
    letterSpacing: 1.2,
    marginBottom: 6,
  },
  title: {
    fontFamily: fontFamily.display,
    fontSize: 26,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontFamily: fontFamily.body,
    fontSize: 13,
    marginTop: 4,
  },
  createGroup: {
    marginHorizontal: 20,
    marginTop: 12,
    marginBottom: 8,
    gap: 10,
  },
  createBtn: {
    height: 52,
    borderRadius: radius.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    ...shadow.card,
  },
  createBtnSecondary: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    ...Platform.select({
      ios: { shadowOpacity: 0 },
      android: { elevation: 0 },
    }),
  },
  createBtnText: {
    fontFamily: fontFamily.bodyBold,
    fontSize: 15,
  },
  list: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 32,
  },
  emptyList: { flexGrow: 1 },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: 14,
    marginBottom: 12,
    ...shadow.card,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  avatarText: {
    color: '#FFFFFF',
    fontFamily: fontFamily.heading,
    fontSize: 15,
  },
  cardBody: { flex: 1, paddingRight: 8 },
  name: {
    fontFamily: fontFamily.heading,
    fontSize: 15,
  },
  email: {
    fontFamily: fontFamily.body,
    fontSize: 12,
    marginTop: 2,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    marginRight: 6,
  },
  statusText: {
    fontFamily: fontFamily.bodySemibold,
    fontSize: 11,
  },
  actions: {
    alignItems: 'flex-end',
    gap: 6,
  },
  actionBtn: {
    minWidth: 78,
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: radius.pill,
  },
  actionText: {
    fontFamily: fontFamily.bodyBold,
    fontSize: 12,
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    paddingTop: 48,
  },
  emptyTitle: {
    fontFamily: fontFamily.heading,
    fontSize: 17,
    marginTop: 12,
  },
  emptyText: {
    fontFamily: fontFamily.body,
    fontSize: 13,
    textAlign: 'center',
    marginTop: 6,
    lineHeight: 19,
  },
});
