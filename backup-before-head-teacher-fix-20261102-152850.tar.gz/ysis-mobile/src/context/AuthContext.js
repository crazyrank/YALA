import { registerInBackground } from '../services/pushNotifications';
import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import * as SecureStore from 'expo-secure-store';
import { clearPortalLogins } from '../services/portalAccess';
import { setSessionEndedHandler } from '../api/client';
import {
  loginOnline,
  hasCompletedFirstLogin,
  getCachedUser,
  unlockWithBiometrics,
  logout as logoutService,
} from '../services/auth';
import {
  getStoredProfilePhotoUri,
  saveProfilePhoto,
  clearStoredProfilePhoto,
} from '../services/profilePhoto';

const AuthContext = createContext(null);
const ONBOARDING_SEEN_KEY = 'ysis_onboarding_seen';
const USER_CACHE_KEY = 'ysis_user_cache';

async function withLocalPhoto(user) {
  if (!user) return user;
  const id = user.id || 'default';
  const localUri = await getStoredProfilePhotoUri(id);
  if (localUri) {
    return { ...user, photo_url: localUri };
  }
  return user;
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [status, setStatus] = useState('loading');
  const userRef = useRef(null);
  userRef.current = user;

  // The server ended the session (refresh refused): sign out at once and remove the
  // saved results-portal login from this phone.
  useEffect(() => {
    setSessionEndedHandler(async () => {
      const current = userRef.current;
      if (!current) return;
      await clearPortalLogins(current.id);
      setUser(null);
      setStatus('needsFirstLogin');
    });
    return () => setSessionEndedHandler(null);
  }, []);

  const resolvePostOnboardingStatus = useCallback(async () => {
    const completed = await hasCompletedFirstLogin();

    if (!completed) {
      setStatus('needsFirstLogin');
      return;
    }

    const cachedUser = await getCachedUser();
    const enriched = await withLocalPhoto(cachedUser);
    setUser(enriched);
    setStatus('needsUnlock');
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const onboardingSeen = await SecureStore.getItemAsync(ONBOARDING_SEEN_KEY);

        if (onboardingSeen !== 'true') {
          setStatus('onboarding');
          return;
        }

        await resolvePostOnboardingStatus();
      } catch (error) {
        console.warn('Auth initialization failed:', error);
        setStatus('needsFirstLogin');
      }
    })();
  }, [resolvePostOnboardingStatus]);

  const finishOnboarding = useCallback(async () => {
    await SecureStore.setItemAsync(ONBOARDING_SEEN_KEY, 'true');
    await resolvePostOnboardingStatus();
  }, [resolvePostOnboardingStatus]);

  const login = useCallback(async (email, password) => {
    const loggedInUser = await loginOnline(email, password);
    const enriched = await withLocalPhoto(loggedInUser);
    setUser(enriched);
    setStatus(loggedInUser.mustChangePassword ? 'needsPasswordChange' : 'authenticated');
    if (!loggedInUser.mustChangePassword) registerInBackground();
    return enriched;
  }, []);

  const unlock = useCallback(async () => {
    const result = await unlockWithBiometrics();

    if (result.unlocked) {
      const cachedUser = await getCachedUser();

      if (!cachedUser) {
        setStatus('needsFirstLogin');
        return { unlocked: false, reason: 'NO_SESSION' };
      }

      const enriched = await withLocalPhoto(cachedUser);
      setUser(enriched);
      setStatus(cachedUser.mustChangePassword ? 'needsPasswordChange' : 'authenticated');
      if (!cachedUser.mustChangePassword) registerInBackground();
    }

    return result;
  }, []);

  const requirePasswordLogin = useCallback(() => {
    setStatus('needsFirstLogin');
  }, []);

  const logout = useCallback(async () => {
    await clearPortalLogins(user?.id);
    await logoutService(user?.id);
    setUser(null);
    setStatus('needsFirstLogin');
  }, [user]);

  // After a forced password change the old session is invalid on the server,
  // so clear it and make the user sign in again.
  const completePasswordChange = useCallback(async () => {
    await clearPortalLogins(user?.id);
    await logoutService(user?.id);
    setUser(null);
    setStatus('needsFirstLogin');
  }, [user]);

  const updateProfilePhoto = useCallback(
    async (sourceUri) => {
      if (!user) {
        throw new Error('Not signed in.');
      }
      const id = user.id || 'default';
      const dest = await saveProfilePhoto(id, sourceUri);
      const next = { ...user, id, photo_url: dest };
      setUser(next);
      await SecureStore.setItemAsync(USER_CACHE_KEY, JSON.stringify(next));
      return dest;
    },
    [user]
  );

  const removeProfilePhoto = useCallback(async () => {
    if (!user) return;
    const id = user.id || 'default';
    await clearStoredProfilePhoto(id);
    const next = { ...user };
    delete next.photo_url;
    setUser(next);
    await SecureStore.setItemAsync(USER_CACHE_KEY, JSON.stringify(next));
  }, [user]);

  return (
    <AuthContext.Provider
      value={{
        user,
        status,
        login,
        unlock,
        logout,
        completePasswordChange,
        requirePasswordLogin,
        finishOnboarding,
        updateProfilePhoto,
        removeProfilePhoto,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);

  if (!ctx) {
    throw new Error('useAuth must be used within AuthProvider');
  }

  return ctx;
}
